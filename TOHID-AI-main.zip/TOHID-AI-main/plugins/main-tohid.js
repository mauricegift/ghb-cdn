let handler = async m =>
  m.reply(
    `

≡ © TOHID TECH Groups & Channels 

─────────────
▢ Join WhatsApp Channel For Updates
https://whatsapp.com/channel/0029VaGyP933bbVC7G0x0i2T

▢ Telegram Group 
https://t.me/Tohid_Tech

─────────────
≡ Disabled links? Chat Directly! 

▢ Group WhatsApp 
 https://chat.whatsapp.com/IqRWSp7pXx8DIMtSgDICGu
─────────────
▢ *Owner instagram*
 https://instagram.com/Tohidkhan6332

▢ *YouTube*
• https://www.youtube.com/@Tohidkhan_6332


`.trim()
  )
handler.help = ['ruth']
handler.tags = ['main']
handler.command = ['groups', 'channels', 'telegram', 'sgp', 'grp']

export default handler
