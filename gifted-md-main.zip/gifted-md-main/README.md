**[SESSION_DOCS](https://pairing.giftedtech.web.id)**

**[GIFTED_YDL](https://youtube.giftedtech.web.id)**

**[GIFTED_CDN](https://storage.giftedtech.web.id)**

**[GITHUB_CDN](https://ghbcdn.giftedtech.web.id)**

**[WA_CHANNEL](https://whatsapp.com/channel/0029Vb3hlgX5kg7G0nFggl0Y)**

**[HEROKU DEPLOY URL](https://dashboard.heroku.com/new?template=https%3A%2F%2Fgithub.com%2Fmauricegift%2Fgifted-md)**
