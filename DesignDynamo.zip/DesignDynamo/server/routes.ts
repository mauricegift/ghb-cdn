import type { Express } from "express";
import { createServer, type Server } from "http";
import axios from 'axios';
import { Buffer } from 'buffer';

const SPOTIFY_TOKEN_ENDPOINT = 'https://accounts.spotify.com/api/token';

async function getAccessToken() {
  const client_id = process.env.SPOTIFY_CLIENT_ID;
  const client_secret = process.env.SPOTIFY_CLIENT_SECRET;

  if (!client_id || !client_secret) {
    throw new Error('Missing Spotify credentials');
  }

  const basic = Buffer.from(`${client_id}:${client_secret}`).toString('base64');

  const response = await fetch(SPOTIFY_TOKEN_ENDPOINT, {
    method: 'POST',
    headers: {
      'Authorization': `Basic ${basic}`,
      'Content-Type': 'application/x-www-form-urlencoded',
    },
    body: 'grant_type=client_credentials'
  });

  if (!response.ok) {
    throw new Error('Failed to get access token');
  }

  const data = await response.json();
  return data.access_token;  // Extracting only the access_token for further usage
}


export function registerRoutes(app: Express): Server {
  const httpServer = createServer(app);

  // Get Spotify access token
  app.get("/api/spotify/token", async (_req, res) => {
    try {
      const token = await getAccessToken();
      res.json(token);
    } catch (error) {
      res.status(500).json({ error: "Failed to get Spotify access token" });
    }
  });

  // Get currently playing song from Spotify
  app.get("/api/spotify/now-playing", async (_req, res) => {
    try {
      const accessToken = await getAccessToken();
      if (!accessToken) {
        return res.status(500).json({ error: "Failed to get access token" });
      }

      // ID lagu "Blue - Yungkai" dari Spotify
      const songId = "1rvMhV6FQggO28NYyxfV0G";  // Menggunakan ID track langsung

      // Mengambil data lagu dari API Spotify
      const response = await axios.get(`https://api.spotify.com/v1/tracks/${songId}`, {
        headers: {
          Authorization: `Bearer ${accessToken}`,
        },
      });

      const song = response.data;

      // Membuat objek data lagu
      const songData = {
        isPlaying: true,
        title: song.name,
        artist: song.artists.map((artist) => artist.name).join(", "),
        album: song.album.name,
        albumImageUrl: song.album.images[0]?.url,  // Cek apakah ada gambar album
        lyrics: "See what I'm currently listening on Spotify", // Lirik tidak tersedia melalui API Spotify secara langsung, jadi bisa menggunakan placeholder
      };

      res.json(songData);
    } catch (error) {
      console.error("Error fetching song data:", error.response?.data || error.message);
      res.status(500).json({ error: "Failed to fetch song data" });
    }
  });





  return httpServer;
}