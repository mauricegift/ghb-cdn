import { Avatar, AvatarImage, AvatarFallback } from "@/components/ui/avatar";
import { Card, CardContent } from "@/components/ui/card";
import { SiGithub, SiSpotify, SiInstagram, SiKalilinux, SiWhatsapp } from "react-icons/si";
import { Badge } from "@/components/ui/badge";
import icon from "../assets/icon.jpg";

export function Header() {
  return (
    <Card className="bg-zinc-900/40 backdrop-blur border-zinc-800">
      <CardContent className="p-8">
        <div className="flex flex-col items-center gap-6">
          <Avatar className="h-24 w-24 ring-2 ring-zinc-800 ring-offset-2 ring-offset-zinc-950">
            <AvatarImage src={icon} alt="Rlzyy" />
            <AvatarFallback>RL</AvatarFallback>
          </Avatar>

          <div className="text-center space-y-2">
            <h1 className="text-2xl font-bold tracking-tight text-zinc-100">
              Rlzyy
              {" "}
              <span className="inline-flex items-center justify-center">
              <div>
              
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    viewBox="0 0 20 20"
                    fill="currentColor"
                    aria-hidden="true"
                    className="ml-1 h-5 w-5 text-indigo-600"
                  >
                    <path d="M6.267 3.455a3.066 3.066 0 001.745-.723 3.066 3.066 0 013.976 0 3.066 3.066 0 001.745.723 3.066 3.066 0 012.812 2.812c.051.643.304 1.254.723 1.745a3.066 3.066 0 010 3.976 3.066 3.066 0 00-.723 1.745 3.066 3.066 0 01-2.812 2.812 3.066 3.066 0 00-1.745.723 3.066 3.066 0 01-3.976 0 3.066 3.066 0 00-1.745-.723 3.066 3.066 0 01-2.812-2.812 3.066 3.066 0 00-.723-1.745 3.066 3.066 0 010-3.976 3.066 3.066 0 00.723-1.745 3.066 3.066 0 012.812-2.812zm7.44 5.252a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z"></path>
                  </svg>
              </div>
              </span>
            </h1>
            <p className="text-sm text-zinc-400">
              夢想家、思想家、実行者。
            </p>
          </div>

          <div className="flex flex-wrap justify-center gap-2">
            <Badge variant="secondary" className="bg-zinc-800/50 text-zinc-300 hover:bg-zinc-700/50 transition-colors border-cyan-500 shadow-[0_0_5px_rgba(59,130,246,0.5)]">
              <SiKalilinux className="h-3.5 w-3.5 mr-1.5" /> Ngoding
            </Badge>
            <Badge variant="secondary" className="bg-zinc-800/50 text-zinc-300 hover:bg-zinc-700/50 transition-colors border-blue-500 shadow-[0_0_5px_rgba(59,130,246,0.5)]">
              💤 Turu
            </Badge>
            <Badge variant="secondary" className="bg-zinc-800/50 text-zinc-300 hover:bg-zinc-700/50 transition-colors border-blue-500 shadow-[0_0_5px_rgba(59,130,246,0.5)]">
              🕊️ Anime
            </Badge>
            <Badge variant="secondary" className="bg-zinc-800/50 text-zinc-300 hover:bg-zinc-700/50 transition-colors border-green-500 shadow-[0_0_5px_rgba(59,130,246,0.5)]">
              <SiSpotify className="h-3.5 w-3.5 mr-1.5" /> Music
            </Badge>
          </div>

          <div className="flex gap-4">
            <a href="https://instagram.com/4rllzyy_" target="_blank" rel="noopener noreferrer" className="text-zinc-400 hover:text-zinc-100 transition-colors">
              <SiInstagram className="h-5 w-5 text-pink-600" />
            </a>
            <a href="https://github.com/rlzyy" target="_blank" rel="noopener noreferrer" className="text-zinc-400 hover:text-zinc-100 transition-colors">
              <SiGithub className="h-5 w-5 text-white" />
            </a>
            <a href="https://open.spotify.com/playlist/1K1Sz1NldB7G8Bibs5GZuI?si=Q7EEsgOSS06YST1IaIXYPg" target="_blank" rel="noopener noreferrer" className="text-zinc-400 hover:text-zinc-100 transition-colors">
              <SiSpotify className="h-5 w-5 text-green-600" />
            </a>
            <a href="https://wa.me/6283899984688?text=hii+irul" target="_blank" rel="noopener noreferrer" className="text-zinc-400 hover:text-zinc-100 transition-colors">
              <SiWhatsapp className="h-5 w-5 text-green-500" />
            </a>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}