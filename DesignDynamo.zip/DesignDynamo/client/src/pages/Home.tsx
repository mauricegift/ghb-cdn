import { Header } from "@/components/Header";
import { SpotifyCard } from "@/components/SpotifyCard";
import { LinkCard } from "@/components/LinkCard";
import { ScrollArea } from "@/components/ui/scroll-area";
import { AspectRatio } from "@/components/ui/aspect-ratio";
import { Toaster, toast } from "react-hot-toast";

const showMe = () => {
  toast.error("Under Development");
};

export default function Home() {
  return (
    <div className="min-h-screen bg-black">
      

      {/* Content */}
      <ScrollArea className="relative z-10 h-screen">
        <div className="container max-w-2xl mx-auto px-4 py-12">
          <Header />

          <div className="mt-8 space-y-3">
            <LinkCard
              title="Whatsapp BOT"
              description="Express your feelings with Confess Bot izumii."
              icon="💭"
              href="https://wa.me/6287740175435?text=.confess"
            />
            <LinkCard 
              title="Izumii Circle"
              description="Find your circle of friends."
              icon="🕊️"
              href="https://chat.whatsapp.com/CvY5sQ0jJku3SzVlfGpVzo"
            />
            <LinkCard
              title="About Me"
              description="about myself"
              icon="🪐" 
              href="https://rulzz.my.id/"
            />
            <Toaster />
            <LinkCard
              title="Support"
              description="Donate as you wish."
              icon="💰"
              href="https://saweria.co/RullZY"
            />
          </div>

          <div className="mt-6">
            <p className="text-white text-center text-zinc-300 mt-1 pb-1">See what I'm currently listening on Spotify</p>
            <SpotifyCard />
          </div>
<footer className="mt-12 pb-8 text-center text-sm text-zinc-500">
            © {new Date().getFullYear()} Izumii. All rights reserved.
          </footer>
          
        </div>
      </ScrollArea>
    </div>
  );
}